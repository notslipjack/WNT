package com.nocarbon.wnt;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Cut-down browser window. No address bar. Loads the WNT .htm file
 * either from assets (bundled snapshot) or from a user-picked file
 * via the Storage Access Framework. Update button reads a tiny
 * JSON manifest (GitHub raw, Pages, or anywhere HTTPS) and sideloads
 * a newer APK when versionCode is higher.
 */
public class MainActivity extends Activity {
    private static final int REQ_OPEN_WNT = 41;
    private static final int REQ_FILE_CHOOSER = 42;
    private static final String PREF = "wnt_wrapper";
    private static final String PREF_URL = "update_manifest_url";
    private static final String PREF_HTM = "wnt_remote_htm";
    private boolean fallingBackToBundled;

    private WebView webView;
    private View toolbar;
    private TextView toolbarHandle;
    private ValueCallback<Uri[]> filePathCallback;
    private boolean updateBusy;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webview);
        toolbar = findViewById(R.id.toolbar);
        toolbarHandle = findViewById(R.id.toolbar_handle);
        Button btnOpen = findViewById(R.id.btn_open);
        Button btnBundled = findViewById(R.id.btn_bundled);
        Button btnUpdate = findViewById(R.id.btn_update);
        toolbarHandle.setOnClickListener(v -> toggleToolbar());

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setTextZoom(100);
        s.setDefaultFontSize(16);
        s.setMinimumFontSize(1);
        s.setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        webView.setInitialScale(100);

        webView.addJavascriptInterface(new WntBridge(), "WntApk");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                String url = uri != null ? uri.toString() : "";
                if (isWntRemoteUrl(url)) {
                    return false;
                }
                String scheme = uri.getScheme() == null ? "" : uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, uri));
                    } catch (ActivityNotFoundException ignored) {
                        view.loadUrl(url);
                    }
                    return true;
                }
                return false;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request != null && request.isForMainFrame() && isWntRemoteUrl(request.getUrl().toString())) {
                    fallbackBundled("GitHub page not reachable, using bundled copy");
                }
            }
        });

        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) {
                    filePathCallback.onReceiveValue(null);
                }
                filePathCallback = callback;
                Intent intent = params.createIntent();
                try {
                    startActivityForResult(intent, REQ_FILE_CHOOSER);
                } catch (ActivityNotFoundException e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "No file picker on this device", Toast.LENGTH_SHORT).show();
                    return false;
                }
                return true;
            }
        });

        btnOpen.setOnClickListener(v -> openWntPicker());
        btnBundled.setOnClickListener(v -> loadBundled());
        Button btnGithub = findViewById(R.id.btn_github);
        if (btnGithub != null) btnGithub.setOnClickListener(v -> loadFromGitHub());
        btnUpdate.setOnClickListener(v -> resolveManifestAndCheck());

        Uri incoming = getIntent() != null ? getIntent().getData() : null;
        if (incoming != null) {
            webView.loadUrl(incoming.toString());
        } else {
            loadFromGitHub();
        }
    }

    public class WntBridge {
        @JavascriptInterface
        public String versionName() {
            return BuildConfig.VERSION_NAME;
        }

        @JavascriptInterface
        public int versionCode() {
            return BuildConfig.VERSION_CODE;
        }

        @JavascriptInterface
        public void checkUpdate() {
            runOnUiThread(MainActivity.this::resolveManifestAndCheck);
        }

        @JavascriptInterface
        public void setManifestUrl(String url) {
            if (url == null) url = "";
            getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(PREF_URL, url.trim()).apply();
        }
    }

    private void toggleToolbar() {
        if (toolbar == null) return;
        boolean show = toolbar.getVisibility() != View.VISIBLE;
        toolbar.setVisibility(show ? View.VISIBLE : View.GONE);
        if (toolbarHandle != null) {
            toolbarHandle.setText(show ? "Hide tools" : getString(R.string.tools_handle));
        }
    }

    private void loadBundled() {
        webView.loadUrl("file:///android_asset/wnt.htm");
    }

    private String remoteHtmUrl() {
        String baked = getString(R.string.remote_htm_url);
        String saved = getSharedPreferences(PREF, MODE_PRIVATE).getString(PREF_HTM, "");
        return firstNonEmpty(saved, baked);
    }

    private boolean isWntRemoteUrl(String url) {
        if (url == null) return false;
        String u = url.toLowerCase();
        return u.contains("raw.githubusercontent.com/notslipjack/wnt/")
            || u.contains("github.com/notslipjack/wnt/raw/");
    }

    private void loadFromGitHub() {
        final String url = remoteHtmUrl();
        if (url.isEmpty()) {
            loadBundled();
            return;
        }
        fallingBackToBundled = false;
        Toast.makeText(this, "Loading WNT.htm from GitHub", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                String html = httpGet(url);
                if (html == null || html.length() < 200 || !html.toLowerCase().contains("<html")) {
                    throw new RuntimeException("GitHub did not return an HTML file");
                }
                File out = new File(getFilesDir(), "WNT.htm");
                FileOutputStream fos = new FileOutputStream(out);
                try {
                    fos.write(html.getBytes("UTF-8"));
                } finally {
                    fos.close();
                }
                final String local = "file://" + out.getAbsolutePath();
                runOnUiThread(() -> webView.loadUrl(local));
            } catch (Exception e) {
                runOnUiThread(() -> fallbackBundled("Could not read WNT.htm from GitHub, using bundled copy"));
            }
        }).start();
    }

    private void fallbackBundled(String msg) {
        if (fallingBackToBundled) return;
        fallingBackToBundled = true;
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
        loadBundled();
    }

    private void openWntPicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[] {
            "text/html",
            "text/plain",
            "application/xhtml+xml",
            "*/*"
        });
        startActivityForResult(intent, REQ_OPEN_WNT);
    }

    private void quietAutoCheck() {
        if (updateBusy) return;
        String baked = getString(R.string.update_manifest_url);
        String saved = getSharedPreferences(PREF, MODE_PRIVATE).getString(PREF_URL, "");
        String url = firstNonEmpty(saved, baked);
        if (!url.isEmpty()) {
            checkForUpdate(url, true);
            return;
        }
        resolveManifestAndCheck(true);
    }

    private void resolveManifestAndCheck() {
        resolveManifestAndCheck(false);
    }

    private void resolveManifestAndCheck(boolean quiet) {
        if (updateBusy) {
            if (!quiet) Toast.makeText(this, "Update already running", Toast.LENGTH_SHORT).show();
            return;
        }
        String baked = getString(R.string.update_manifest_url);
        String saved = getSharedPreferences(PREF, MODE_PRIVATE).getString(PREF_URL, "");
        webView.evaluateJavascript(
            "(function(){try{return localStorage.getItem('wnt_apk_update_url')||'';}catch(e){return '';}})()",
            value -> {
                String fromPage = unwrapJsString(value);
                String url = firstNonEmpty(fromPage, saved, baked);
                if (url.isEmpty()) {
                    if (!quiet) {
                        Toast.makeText(this, "Set an update JSON URL in APK update manager first", Toast.LENGTH_LONG).show();
                    }
                    return;
                }
                checkForUpdate(url, quiet);
            }
        );
    }

    private static String unwrapJsString(String value) {
        if (value == null || "null".equals(value)) return "";
        value = value.trim();
        if (value.length() >= 2 && value.charAt(0) == '"' && value.charAt(value.length() - 1) == '"') {
            value = value.substring(1, value.length() - 1);
        }
        return value.replace("\\/", "/").replace("\\\"", "\"").trim();
    }

    private static String firstNonEmpty(String... parts) {
        if (parts == null) return "";
        for (String p : parts) {
            if (p != null && !p.trim().isEmpty()) return p.trim();
        }
        return "";
    }

    private void checkForUpdate(String manifestUrl) {
        checkForUpdate(manifestUrl, false);
    }

    private void checkForUpdate(String manifestUrl, boolean quiet) {
        updateBusy = true;
        if (!quiet) Toast.makeText(this, "Checking " + manifestUrl, Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            try {
                JSONObject json = new JSONObject(httpGet(manifestUrl));
                int remoteCode = json.optInt("versionCode", json.optInt("build", 0));
                String remoteName = json.optString("versionName", json.optString("version", ""));
                String apkUrl = json.optString("apkUrl", json.optString("apk", ""));
                String notes = json.optString("notes", "");
                int localCode = BuildConfig.VERSION_CODE;
                if (remoteCode <= localCode) {
                    if (!quiet) {
                        runOnUiThread(() -> {
                            loadFromGitHub();
                            Toast.makeText(MainActivity.this, "This APK is current. Reloaded WNT.htm from GitHub.", Toast.LENGTH_SHORT).show();
                        });
                    }
                    return;
                }
                if (apkUrl.isEmpty()) {
                    if (!quiet) uiToast("Manifest has a newer wrapper but no apkUrl");
                    return;
                }
                int snoozed = getSharedPreferences(PREF, MODE_PRIVATE).getInt("wnt_update_snooze", 0);
                if (quiet && snoozed == remoteCode) return;
                String msg = "New Android wrapper " + remoteName + " (build " + remoteCode + ").\n\nThis is only for the APK shell. Page text updates when you replace WNT.htm on GitHub.";
                if (!notes.isEmpty()) msg += "\n\n" + notes;
                final String finalApk = apkUrl;
                final String finalMsg = msg;
                final int finalCode = remoteCode;
                runOnUiThread(() -> new AlertDialog.Builder(this)
                    .setTitle("New wrapper APK?")
                    .setMessage(finalMsg)
                    .setNegativeButton("Not now", (d, w) ->
                        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("wnt_update_snooze", finalCode).apply())
                    .setPositiveButton("Download APK", (d, w) -> downloadAndInstall(finalApk))
                    .show());
            } catch (Exception e) {
                if (!quiet) uiToast("Update check failed: " + e.getMessage());
            } finally {
                updateBusy = false;
            }
        }).start();
    }

    private void downloadAndInstall(String apkUrl) {
        if (Build.VERSION.SDK_INT >= 26 && !getPackageManager().canRequestPackageInstalls()) {
            Toast.makeText(this, "Allow installs from this app, then tap Update again", Toast.LENGTH_LONG).show();
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            } catch (ActivityNotFoundException ignored) {}
            return;
        }
        updateBusy = true;
        Toast.makeText(this, "Downloading APK", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            File out = new File(getCacheDir(), "wnt-update.apk");
            HttpURLConnection conn = null;
            try {
                conn = (HttpURLConnection) new URL(apkUrl).openConnection();
                conn.setInstanceFollowRedirects(true);
                conn.setConnectTimeout(20000);
                conn.setReadTimeout(60000);
                conn.connect();
                int code = conn.getResponseCode();
                if (code >= 400) throw new RuntimeException("HTTP " + code);
                try (InputStream in = conn.getInputStream(); FileOutputStream fos = new FileOutputStream(out)) {
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = in.read(buf)) >= 0) fos.write(buf, 0, n);
                }
                runOnUiThread(() -> installApk(out));
            } catch (Exception e) {
                uiToast("Download failed: " + e.getMessage());
            } finally {
                if (conn != null) conn.disconnect();
                updateBusy = false;
            }
        }).start();
    }

    private void installApk(File apk) {
        try {
            Uri uri = FileProvider.getUriForFile(this, "com.nocarbon.wnt.fileprovider", apk);
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setDataAndType(uri, "application/vnd.android.package-archive");
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Could not open installer: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private void uiToast(String msg) {
        runOnUiThread(() -> Toast.makeText(this, msg, Toast.LENGTH_LONG).show());
    }

    private static String httpGet(String spec) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(spec).openConnection();
        conn.setInstanceFollowRedirects(true);
        conn.setConnectTimeout(15000);
        conn.setReadTimeout(20000);
        conn.setRequestProperty("Accept", "application/json,text/plain,*/*");
        conn.setRequestProperty("User-Agent", "WNT-Android-Wrapper/" + BuildConfig.VERSION_NAME);
        try {
            int code = conn.getResponseCode();
            InputStream in = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (in == null) throw new RuntimeException("HTTP " + code);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) >= 0) bos.write(buf, 0, n);
            String body = bos.toString("UTF-8");
            if (code >= 400) throw new RuntimeException("HTTP " + code + " " + body);
            return body;
        } finally {
            conn.disconnect();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE_CHOOSER) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(result);
                filePathCallback = null;
            }
            return;
        }
        if (requestCode == REQ_OPEN_WNT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try {
                getContentResolver().takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                );
            } catch (SecurityException ignored) {
            }
            webView.loadUrl(uri.toString());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
